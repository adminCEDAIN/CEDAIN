<?php
/**
 * Thumbnail Single Template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


the_post_thumbnail();

?>