<?php
/**
 * Posted Single Template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

donate_get_template( 'loop/posted.php' );

?>
