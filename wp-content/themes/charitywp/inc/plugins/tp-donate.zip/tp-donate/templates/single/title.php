<?php
/**
 * Title Single Template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<header>

	<h1><?php the_title() ?></h1>

</header>