<?php
if ( !defined( 'ABSPATH' ) )
    exit();

/**
 * Cart is empty
 */
?>

<div class="donate_messages">
    <span class="empty_cart">
        <?php _e( 'You have no donate item!', 'tp-donate' ) ?>
    </span>
</div>
