<?php

// Silence is golden! Nothing to say